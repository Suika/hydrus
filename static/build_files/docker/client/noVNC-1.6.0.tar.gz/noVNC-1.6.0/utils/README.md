## WebSockets Proxy/Bridge

Websockify has been forked out into its own project. `novnc_proxy` will
automatically download it here if it is not already present and not
installed as system-wide.

For more detailed description and usage information please refer to
the [websockify README](https://github.com/novnc/websockify/blob/master/README.md).

The other versions of websockify (C, Node.js) and the associated test
programs have been moved to
[websockify](https://github.com/novnc/websockify).  Websockify was
formerly named wsproxy.

